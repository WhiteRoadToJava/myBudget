package com.mybudget.server.dto;

import java.util.Set;

import com.mybudget.server.modules.enums.Role;

public class RegisterResponse {
    private String message;
    private String username;
    private Set<Role> roles;
    private boolean requiresActivation;

    public RegisterResponse(String message, String username, Set<Role> roles) {
        this.message = message;
        this.username = username;

        this.roles = roles;
    }

    public RegisterResponse(String message, String username, Set<Role> roles, boolean requiresActivation){
        this.message = message;
        this.username = username;
        this.roles = roles;
        this.requiresActivation = requiresActivation;
    }





    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public boolean isRequiresActivation() {
        return requiresActivation;
    }

    public void setRequiresActivation(boolean requiresActivation) {
        this.requiresActivation = requiresActivation;
    }

}