package com.mybudget.server.services.account;

import com.mybudget.server.dto.Transaction;
import com.mybudget.server.dto.accounts.AccountRequest;
import com.mybudget.server.dto.accounts.AccountResponse;
import com.mybudget.server.dto.accounts.AllAccounts;
import com.mybudget.server.dto.accounts.UpdateAccountStatus;
import com.mybudget.server.dto.transfer.TransferRequest;
import com.mybudget.server.exeptions.ResourceNotFoundException;
import com.mybudget.server.modules.*;
import com.mybudget.server.modules.enums.AccountStatus;
import com.mybudget.server.repositories.AccountRepository;
import com.mybudget.server.repositories.ExpenseRepository;
import com.mybudget.server.repositories.IncomseRepository;
import com.mybudget.server.repositories.TransferRepository;
import com.mybudget.server.util.UserUtils;
import com.mybudget.server.mapMappers.AccountMapper;
import com.mybudget.server.mapMappers.UserMappers;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AccountService {
    private final UserUtils userUtils;
    private final AccountRepository accountRepository;
    private final IncomseRepository incomseRepository;
    private final ExpenseRepository expenseRepository;
    private final TransferRepository transferRepository;
    private final AccountMapper accountMapper;
    private final UserMappers userMappers;


    public AccountResponse createAccount(AccountRequest accountRequest) {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        if (findAccountByNameAndUser(accountRequest.getName(), currentUser)) {
            throw new ResourceNotFoundException("Account already exists");
        }
        Date createdAt = new Date();

        Account account = new Account(
                accountRequest.getName(),
                accountRequest.getDescription(),
                accountRequest.getBalance(),
                accountRequest.getTotalBalance(),
                accountRequest.getCurrency(),
                accountRequest.getType(),
                currentUser,
                createdAt.toString()
        );
        AccountResponse accountResponse = accountMapper.mapToAccountResponse(accountRepository.save(account));
        return accountResponse;
    }

    public AccountResponse updateAcoount(Account accouunt) {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        Account existedAccount = accountRepository.findByIdAndUser(accouunt.getId(), currentUser);
        if (existedAccount == null) {
            throw new ResourceNotFoundException("Account not found");
        }
        existedAccount.setName(accouunt.getName());
        existedAccount.setDescription(accouunt.getDescription());
        existedAccount.setCurrency(accouunt.getCurrency());
        existedAccount.setType(accouunt.getType());

        double oldBalance = existedAccount.getBalance();
        double newBslsnce = accouunt.getBalance();
        double oldTotalBalance = existedAccount.getTotalBalance();
        existedAccount.setTotalBalance(calculateNewTotal(oldBalance, newBslsnce, oldTotalBalance));
        existedAccount.setBalance(newBslsnce);
        return accountMapper.mapToAccountResponse(accountRepository.save(existedAccount));
    }

    private Double calculateNewTotal(Double oldBalance, Double newBalance, Double currentTotal) {

        return currentTotal + (newBalance - oldBalance);
    }

    public AccountResponse updateTotalBalanceWithReceivedTransfer(Account account, Double amount) {
        String accountId = account.getId();
        Account updatedAccount = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Double totalBalance = account.getTotalBalance() + amount;
        updatedAccount.setTotalBalance(totalBalance);

        return accountMapper.mapToAccountResponse(accountRepository.save(updatedAccount));
    }

    public AccountResponse updateTotalBalanceWithSemdTransfer(Account account, Double amount) {
        String accountId = account.getId();
        Account updatedAccount = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        Double totalBalance = account.getTotalBalance() - amount;
        updatedAccount.setTotalBalance(totalBalance);

        return accountMapper.mapToAccountResponse(accountRepository.save(updatedAccount));
    }

    @Transactional
    public void deleteAccount(String accountId) {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        Account account = accountRepository.findByIdAndUser(accountId, currentUser);
        if (account == null) {
            throw new ResourceNotFoundException("Account not found");
        }
        incomseRepository.deleteAllByAccount(account);
        expenseRepository.deleteAllByAccount(account);

        accountRepository.delete(account);
    }


    public AllAccounts getAllAccounts() {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        List<Account> accounts = accountRepository.findAllByUser(currentUser);
        int totalAccounts = accounts.size();

        // ✅ currency → total balance
        Map<String, Double> totalBalanceByCurrency = new HashMap<>();

        for (Account account : accounts) {
            if (account.getTotalBalance() == null) {
                account.setTotalBalance(0.0);
                accountRepository.save(account);
            }
            if (account.getStatus() == null) {
                account.setStatus(Collections.singleton(AccountStatus.ACTIVE));
            }

            // ✅ Group and sum by currency
            totalBalanceByCurrency.merge(
                    account.getCurrency(),
                    account.getTotalBalance(),
                    Double::sum
            );
        }

        AllAccounts allAccounts = new AllAccounts(accounts, totalAccounts, totalBalanceByCurrency);
        return allAccounts;
    }


    public AccountResponse updateAccountStatus(String accountId, UpdateAccountStatus status) {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        Account targedAccount = accountRepository.findByIdAndUser(accountId, currentUser);

        targedAccount.setStatus(status.getStatus());

        accountRepository.save(targedAccount);
        return mapToAccountResponse(targedAccount);
    }


    public List<Transaction> getAllAccountTransactions(Account account) {
        List<Incomse> incomseList = incomseRepository.findAllByAccount(account);
        List<Expense> expenseList = expenseRepository.findAllByAccount(account);
        List<Transfer> transferList = transferRepository.findAllBySourceAccountOrDestinationAccount(account, account);
        List<Transaction> transactions = new ArrayList<>();
        transactions.addAll(incomseList.stream().map(this::mapIToTransation).toList());
        transactions.addAll(expenseList.stream().map(this::mapExpenseToTranaction).toList());
        transactions.addAll(transferList.stream()
                .map(t -> mapTransferToTransaction(t, account)).toList());
        return transactions;
    }

    public List<Transaction> getUserAllTransaction() {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        List<Incomse> incomses = incomseRepository.findAllByUser(currentUser);
        List<Expense> expenses = expenseRepository.findAllByUser(currentUser);
        List<Transfer> transfers = transferRepository.findAllByUser(currentUser.getId());

        List<Transaction> transactions = new ArrayList<>();
        transactions.addAll(incomses.stream().map(this::mapIToTransation).toList());
        transactions.addAll(expenses.stream().map(this::mapExpenseToTranaction).toList());
        transactions.addAll(transfers.stream().map(this::mapTransferToTransaction).toList());

        return transactions;
    }

    public List<Transaction> getAllIncomseExpenseTransactins() {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        List<Incomse> incomseList = incomseRepository.findAllByUser(currentUser);
        List<Expense> expenseList = expenseRepository.findAllByUser(currentUser);

        List<Transaction> transactionList = new ArrayList<>();
        transactionList.addAll(incomseList.stream().map(this::mapIToTransation).toList());
        transactionList.addAll((expenseList.stream().map(this::mapExpenseToTranaction).toList()));
        return transactionList;
    }


    private boolean findAccountByNameAndUser(String accountName, User currentUser) {
        return accountRepository.findByNameAndUser(accountName, currentUser).isPresent();
    }

    public AccountResponse getAccountById(String accountId) {
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        Account account = accountRepository.findByIdAndUser(accountId, currentUser);
        if (account == null) {
            throw new ResourceNotFoundException("Account not found");
        }
        return mapToAccountResponse(account);
    }

    private AccountResponse mapToAccountResponse(Account account) {
        return accountMapper.mapToAccountResponse(account);
    }


    public Account updateTotalBalanaceWithExpense(Account account, double amount) {
        account.setTotalBalance(account.getTotalBalance() - amount);
        return accountRepository.save(account);
    }

    public void updateTotalBalanceWithIncome(Account account, double amount) {
        if (account != null) {
            if (account.getTotalBalance() == null) {
                account.setTotalBalance(0.0);
                accountRepository.save(account);
            }
            if (account.getBalance() == null) {
                throw new ResourceNotFoundException("Balance is null");
            }
            account.setTotalBalance(account.getTotalBalance() + amount);
            accountRepository.save(account);
        }
    }

    public Account updateTotalBalanceWithUpdateIncome(Account account, Incomse incomse, double amount) {
        Double oldTotalbalance = account.getTotalBalance();
        Double newTotalBalance = oldTotalbalance - incomse.getAmount() + amount;
        account.setTotalBalance(newTotalBalance);
        return accountRepository.save(account);
    }

    @Transactional
    public Account updateTotalBalanceWithUpdateExpense(Account account, Expense expense, double amount) {
        Double oldTotalbalance = account.getTotalBalance();
        Double newTotalBalance = oldTotalbalance + expense.getAmount() - amount;
        account.setTotalBalance(newTotalBalance);
        return accountRepository.save(account);
    }

    @Transactional
    public void updateTotalBalanceWithDeleteIncomse(Account account, Double amount) {
        if (account != null) {
            account.setTotalBalance(account.getTotalBalance() - amount);
            accountRepository.save(account);
        }
    }

    @Transactional
    public void updateTotalBalanceWithDeleteExpense(Account account, Double amount) {
        if (account != null) {
            account.setTotalBalance(account.getTotalBalance() + amount);
            accountRepository.save(account);
        }
    }


    @Transactional
    public String updateAccountsWithUpadateTransfer(Account accountSend, Account accountDestination, Transfer transfer, TransferRequest request) {
        if (accountSend != null) {
            Double oldAccountSendTotal = accountSend.getTotalBalance();
            Double newAccountSentTotal = oldAccountSendTotal + transfer.getAmountSent() - request.getAmountSent();
            accountSend.setTotalBalance(newAccountSentTotal);
            accountRepository.save(accountSend);

        }
        if (accountDestination != null) {
            Double oldAccountDestinationTotal = accountDestination.getTotalBalance();
            Double newAccountDestinationTotal = oldAccountDestinationTotal - transfer.getAmountReceived() + request.getAmountReceived();
            accountDestination.setTotalBalance(newAccountDestinationTotal);
            accountRepository.save(accountDestination);
        }
        return "success";
    }

    @Transactional
    public String updateAccountsTotalBalanceWithDeleteTransfer(Transfer transfer) {
        String sourceAccountId = "";
        if (transfer.getSourceAccount() != null) {
            sourceAccountId = transfer.getSourceAccount().getId();
            accountRepository.findById(sourceAccountId).ifPresent(sourceAccount -> {
                Double newBalance = sourceAccount.getTotalBalance() + transfer.getAmountSent();
                sourceAccount.setTotalBalance(newBalance);
                accountRepository.save(sourceAccount);
            });
        }
        String destinationAccountId = "";
        if (transfer.getDestinationAccount() != null) {
            destinationAccountId = transfer.getDestinationAccount().getId();
            accountRepository.findById(destinationAccountId).ifPresent(destinationAccount -> {
                Double newBalance = destinationAccount.getTotalBalance() - transfer.getAmountReceived();
                destinationAccount.setTotalBalance(newBalance);
                accountRepository.save(destinationAccount);
            });
        }
        return "success";
    }


    public List<Transaction> getTransactionsBetweenTwoDates(String fromDate, String toDate) {
        // confirm the user is authenticated and heseilf that do the  rappor
        User currentUser = userUtils.getCurrentAuthenticatedUser();
        LocalDateTime date1 = LocalDate.parse(fromDate).atStartOfDay();
        LocalDateTime date2 = LocalDate.parse(toDate).atStartOfDay();
        List<Incomse> incomseList = incomseRepository.findByUserAndCreatedAtBetween(currentUser, date1, date2);
        List<Expense> expenseList = expenseRepository.findByUserAndCreatedAtBetween(currentUser, date1, date2);
        List<Transfer> transferList = transferRepository.findByUserAndCreatedAtBetween(currentUser, date1, date2);

        List<Transaction> transactionList = new ArrayList<>();
        transactionList.addAll(incomseList.stream().map(this::mapIToTransation).toList());
        transactionList.addAll(expenseList.stream().map(this::mapExpenseToTranaction).toList());
        transactionList.addAll(transferList.stream().map(this::mapTransferToTransaction).toList());
        return transactionList;

    }


    private Transaction mapTransferToTransaction(Transfer transfer, Account account) {
        return accountMapper.mapTransferToTransaction(transfer, account);
    }

    private Transaction mapExpenseToTranaction(Expense expense) {
        return accountMapper.mapExpenseToTranaction(expense);
    }

    private Transaction mapIToTransation(Incomse incomse) {
        return accountMapper.mapIToTransation(incomse);
    }

    private Transaction mapTransferToTransaction(Transfer transfer) {
        return accountMapper.mapTransferToTransaction(transfer);
    }
}
